#Karina Fauzia Setiadi 2402838 

d = int(input("masukkan angka pertama: "))
e = int(input("masukkan angka kedua: "))
f = int(input("masukkan angka ketiga: "))
Sum = sum([d,e,f])
print("Hasil dari penjumlahan", d, "dan", e, "dan", f, "adalah", Sum)