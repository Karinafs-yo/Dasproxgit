#Karina Fauzia Setiadi 2402838 

print('Menghitung Luas Segitiga')

alas = float(input('Input alas: '))
tinggi = float(input('Input tinggi: '))
 
luas = 0.5 * alas * tinggi
print('Luas segitiga = ',round(luas,2))