#Karina fauzia setiadi 2402838

#Kasus 1
print('SELAMAT DATANG DIPROGRAM PENGECEKAN NILAI')
x = int(input('Masukan nilai anda :'))
if (x >= 90):
    print("Selamat anda mendapat nilai A")
elif (x < 90 and x >= 80):
    print("Keren! anda mendapat nilai B")
elif(x < 80 and x >= 70):
    print("Jelek banget bilai C")
elif(x < 70):
    print("Belajar yang bener. Nilaimu D!")


