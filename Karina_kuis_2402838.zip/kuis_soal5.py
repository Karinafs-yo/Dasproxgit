#Pak Oki memiliki sebuah mobil dengan spesifikasi seperti berikut:
# ● Merk: Honda
# ● Tipe: HRV
# ● Tahun: 2018
# ● Warna: Hitam
# ● No. Polisi: D 1234 ABC
# ● Bensin: Pertalite
# ● Tranmisi: Manual
# Karena usahanya semakin sukses, Pak Oki mengganti mobilnya dengan mobil keluaran
# terbaru, yaitu Honda Civic Turbo tahun 2023 bewarna Merah. Mobil baru Pak Oki
# menggunakan bensin Pertamax dan transmisinya Automatic. Plat nomor mobil baru
# Pak Oki adalah D 0 KI. Buatlah program yang dapat menyimpan detail informasi dari
# mobil lama Pak Oki sekaligus dapat mengupdate informasi mobil baru yang dibeli oleh
# Pak Oki (berdasarkan inputan). Output program yang diinginkan oleh Pak Oki adalah
#bobot: 25 point)

mobil_info{
    merk ="honda",
    tipe ="hrv",
    warna ="hitam",
    Tahun ="2018"
}

print("Masukkan informasi detail mobil baru:")
lebar = float(input('Input lebar berapa meter: '))
