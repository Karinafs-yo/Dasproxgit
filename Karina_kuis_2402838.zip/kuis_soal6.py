#Ibu Novia merupakan salah satu guru Matematika di SMA Bandung, beliau ingin
# memiliki program yang dapat menyimpan 10 nilai Matematika siswanya. Adapun
# susunan nilainya adalah sebagai berikut:
# 78, 90, 56, 98, 65, 38, 42, 74, 89, dan 90.
# Beliau ingin program yang apabila beliau mengetikan no urut siswa, maka program
# akan memunculkan nilai dari siswa yang memiliki no. urut tersebut. Sebagai contoh,
# ketika beliau mengetikan no. urut 1 maka nilai yang keluar adalah 78 dan ketika
# mengetikan no. urut 3 maka nila yang keluar adalah 56, dst. Buatlah program yang
# dapat memenuhi kebutuhan Bu Novia. (bobot: 20 point)


#karina fauzia setiadi 2402838 RPL 1A
nilai= ["78", "90", "56", "98", "65", "38", "42", "74", "89", "90"]
no_urut = int(input('Input nomor urut:'))

print(a[1:5])




