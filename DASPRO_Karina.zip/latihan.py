"""Tugas Karina Fauzia Setiadi
NIM 2402838
KELAS RPL A"""
nama = input("nama anda: ")
umur = input("umur anda: ")
print (f"selamat datang, {nama} umur kamu adalah {umur}")

