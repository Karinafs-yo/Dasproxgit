#Karina Fauzia Setiadi 2402838 Tugas if

#input nilai uas
x= int(input('Input nilai UAS: '))
#kasih pernyataan if else
if(x >= 60):
    print("Lulus")
else:
    print("Tidak lulus")
