#Karina Fauzia Setiadi 2402838
for i in range(1, 51):
    #buat nentuin dikelipatan lima harus munculin "pass"
    if i % 5 == 0:
        print("pass")
    else:
        print(i)
