#Karina Fauzia Setiadi_2402838_RPL1A
a = float(input("input bilangan : "))
