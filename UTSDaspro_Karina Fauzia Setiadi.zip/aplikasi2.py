#Karina Fauzia Setiadi_2402838_RPL1A
a = float(input("Input bilangan : "))
while a:
    a +1
if a < 0:
    print("break")