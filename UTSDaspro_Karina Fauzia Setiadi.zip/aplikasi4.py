#Karina Fauzia Setiadi_2402838_RPL1A
nim = float(input("Input 3 digit NIM terakhir : "))
if (nim >= 1 <= 50):
    print("Silakan masuk ke kelas K1")
elif (nim >= 51 <= 100):
    print("Silakan masuk ke kelas K3")
elif (nim >= 101 <= 150):
    print("Silakan masuk ke kelas K5")
elif (nim >= 151):
    print("Silakan masuk ke kelas K7")

    


