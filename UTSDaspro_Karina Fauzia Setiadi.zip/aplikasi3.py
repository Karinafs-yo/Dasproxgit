#Karina Fauzia Setiadi_2402838_RPL1A
n = float(input("Masukkan N : "))
print(f"{n} ""Bebek kecil berenang \n Menyusuri sungai yang deras\n Induknya mencari kwek kwek kwek\n Hanya  ekor yang pulang")