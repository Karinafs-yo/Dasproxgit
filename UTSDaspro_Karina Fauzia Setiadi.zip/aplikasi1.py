#Karina Fauzia Setiadi_2402838_RPL1A
print(f"Silakan Login \n")
a = str(input("Username : "))
b = str(input("Password : "))
if (a is "loginUTS"):
    if (a is "RPL2024"):
        print("login salah kesempatan anda dua kali lagi")
else:
    print("Selamat datang di aplikasi prodi rpl")
    
    


