#Karina Fauzia Setiadi 2402838
###Anda diberikan daftar angka yang mungkin mengandung duplikasi. Tugas anda adalah menghapus semua duplikasi dan mengembalikan daftar angka yang hanya berisi elemen unik.
numbers = [10, 20, 20, 30, 40, 50, 50, 60]
output = [10, 20, 30, 40, 50, 60]

#pengerjaan
a = {10, 20, 20, 30, 40, 50, 50, 60}
print(a)