#Karina Fauzia Setiadi 2402838 RPL 1A

#Dictionary yang berisi student_info
student_info = {
    "Alice": {"age": 20, "major": "Computer Science"},
    "Bob": {"age": 21, "major": "Mathematics"},
    "Charlie": {"age": 19, "major": "physics"},
}
(student_info)
#variabel yang menampung user dan perintah menginputkan nama siswa
nama = input("Inputkan nama siswa: ")
#Sinkronkan antara variable nama ke variable data_nama  yang memuat dictionary dengan fungsi get()
data_nama =student_info.get(nama)
#perintah print untuk menghasilkan output
print(f"Umur {nama} adalah {data_nama["age"]} dan Prodinya adalah {data_nama["major"]}")
