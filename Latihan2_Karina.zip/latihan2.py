"""Karina Fauzia Setiadi
NIM 2402838
KELAS RPL A"""


#tugas 2
nama = input("nama anda: ")
tahun = (int(input("tahun lahir: ")))
print (f"Hallo {nama}, umur kamu adalah {2024-tahun}")