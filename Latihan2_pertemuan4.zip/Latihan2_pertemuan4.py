#Karina fauzia setiadi 2402838

students = {
    "Alice": "Computer Science",
    "Bob": "Mathematics",
    "Charlie": "Physics",
    "David": "Computer Science",
    "Eva": "Mathematics"
}

students.update({"Alice": "Prodi Computer Science", "Bob": "Prodi Mathematics", "Charlie": "Prodi Physics", "David": "Prodi Computer Science", "Eva": "Prodi Mathematics"})
print(students)
value_counts = {value: list(students.values()).count(value)for value in students.values()}
print(value_counts)
